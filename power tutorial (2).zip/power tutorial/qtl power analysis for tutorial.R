##Set working directory!

##install packages

#install.packages(c("qtl", lme4))
#install.packages("devtools")
#library(devtools)
#install_github("cran/qtlDesign")

##load libraries
library(lme4)
library(qtl)
library(qtlDesign)

##Import the genotype data and make anything > |mean +- 3SD| into NA
qtlfile <- read.cross("csvs", ".", "Cortijo-epigenotypes-QTL.csv", "qtlfile_pheno.csv", crosstype = "riself" )
rownames(qtlfile$pheno) <- as.character(qtlfile$pheno[,"id"], as.is = TRUE); qtlfile$pheno[c(which(qtlfile$pheno[,1] > (mean(qtlfile$pheno[,1], na.rm = TRUE) + 3*(sd(qtlfile$pheno[,1], na.rm = TRUE)))),which(qtlfile$pheno[,1] < (mean(qtlfile$pheno[,1], na.rm = TRUE) - 3*(sd(qtlfile$pheno[,1], na.rm = TRUE))))),1] <- NA; qtlfile$pheno[c(which(qtlfile$pheno[,2] > (mean(qtlfile$pheno[,2], na.rm = TRUE) + 3*(sd(qtlfile$pheno[,2], na.rm = TRUE)))),which(qtlfile$pheno[,2] < (mean(qtlfile$pheno[,2], na.rm = TRUE) - 3*(sd(qtlfile$pheno[,2], na.rm = TRUE))))),2] <- NA; qtlfile2 <- qtlfile; qtlfile_pheno2 <- qtlfile$pheno


##Import stats file
stats <- read.csv("stats.csv")

##We are going to create an R object with the phenotype names.
phes <- phenames(qtlfile)[c(1,2)]

##Perform the QTL analysis and the permutations for the significance
##threshold
s1<-scanone(qtlfile, pheno.col = phes, method = "hk")
modelperms <-scanone(qtlfile, pheno.col = phes, method = "hk", n.perm = 1000)

##Import the raw data
##This is the data that was used to generate the file 
##"qtlfile_pheno.csv", which is the data per replicate,
##not the summary data per strain.
##Import the raw data in the same order as the phenotypes in the file
##qtlfile_pheno.csv".
##So, first, look at the columns of "qtlfile_pheno.csv"
colnames(qtlfile$pheno)
##We see that the traits are:
##(1) "raul.Julian.flowering.date"
##and
##(2) "cortijo.Julian.flowering.date"
##
##So this means we need to import the raw data 
##"raul.Julian.flowering.date.csv" as trait1
##and
##"cortijo.Julian.flowering.date.csv" as trait2

trait1 <- read.csv("raul.Julian.flowering.date.csv"); change_elements_to_na <- function(vector, elements_to_check) {vector[vector %in% elements_to_check] <- NA; return(vector)}; trait1[,1] <- change_elements_to_na(trait1[,1], rownames(qtlfile$pheno[which(is.na(qtlfile$pheno[,1])),])); trait1 <- trait1[which(!is.na(trait1[,1])),]
trait2 <- read.csv("cortijo.Julian.flowering.date.csv"); trait2[,1] <- change_elements_to_na(trait2[,1], rownames(qtlfile$pheno[which(is.na(qtlfile$pheno[,2])),])); trait2 <- trait2[which(!is.na(trait2[,1])),]

##Get rid of strains from the raw data that were not used in the
##genetic mapping

qtlfile_pheno <- qtlfile$pheno
qtlfile_pheno$strain <- rownames(qtlfile_pheno); qtlfile_pheno_extra <- qtlfile_pheno

trait1b <- merge(trait1, qtlfile_pheno, by = "strain", all.x = FALSE, all.y = FALSE)
if(length(which(is.na(trait1b[,3]))) > 0)
{trait1c <- trait1b[-c(which(is.na(trait1b[,3]))),]}else
  {trait1c <- trait1b}

trait2b <- merge(trait2, qtlfile_pheno, by = "strain", all.x = FALSE, all.y = FALSE)
if(length(which(is.na(trait2b[,4]))) > 0)
{trait2c <- trait2b[-c(which(is.na(trait2b[,4]))),]}else
  {trait2c <- trait2b}

##Now to do a power analysis.

##This script is only designed for comparing exactly two phenotypes!

##Look at the column names
colnames(qtlfile$pheno)

##Broad-sense heritability for first phenotype
fit.trait1 <- lmer(as.numeric(trait1c[,2]) ~ (1 | strain), trait1c)
fit.trait.summary1 <- as.data.frame(summary(fit.trait1)$varcor)
heritability1 <- fit.trait.summary1[1,4]/(fit.trait.summary1[2,4]+fit.trait.summary1[1,4])
heritability1

##Find the number of biological replicates of the first phenotype
trait.length1 <- as.matrix(by(trait1c, trait1c$strain, function(d){
  
  length(which(!is.na(as.numeric(as.character(d[,2])))))
  
}

)

)
summary(trait.length1)
round.length1 <- round(mean(trait.length1))

##Broad-sense heritability for second phenotype
fit.trait2 <- lmer(as.numeric(trait2c[,2]) ~ (1 | strain), trait2c)
fit.trait.summary2 <- as.data.frame(summary(fit.trait2)$varcor)
heritability2 <- fit.trait.summary2[1,4]/(fit.trait.summary2[2,4]+fit.trait.summary2[1,4])
heritability2

##Find the number of biological replicates of the second phenotype
trait.length2 <- as.matrix(by(trait2c, trait2c$strain, function(d){
  
  length(which(!is.na(as.numeric(as.character(d[,2])))))
  
}

)

)
summary(trait.length2)
round.length2 <- round(mean(trait.length2))

##Look at the stats
stats

##Choose a row
row <- 2

##Open a PDF file for the graphs
pdf(paste0("marker.compare.", stats[row,"terms"], ".pdf"))

##Then do the calculations

#which population is the phantom? 1 or 2?
phantom <- 2

##Now do the power analysis, and change bio.reps below to the number of biological reps (round number)
##Use n from "present" population
##Use effect from "present" population. Find effect of QTL in "present" population that is missing in "phantom" population
##Use gen.var from "present" population
##Use env.var from "present" population
##Use thresh from "present" population
##Use bio.reps from "present" population

##Pick out the chromosome and position of the closest marker to that locus
qc <- stats[row,"chr"]
qp <- stats[row,"pos"]
mname <- find.marker(qtlfile, qc, qp)
#mname

qtlfile <- qtlfile2; qtlfile_pheno <- cbind(qtlfile_pheno2, qtlfile_pheno_extra[,4]); colnames(qtlfile_pheno)[4] <- "strain"; qtlfile_pheno <- qtlfile_pheno[,c((3-phantom), phantom, 3, 4)]; qtlfile$pheno <- qtlfile$pheno[,c((3-phantom), phantom, 3)]; present <- 1

output <- effectplot(qtlfile, pheno.col = present, mname1=mname)
effect.size <- abs((output$Means[1] - output$Means[2])/2)
output.matrix <- t(rbind(output$Means, output$SEs))
colnames(output.matrix) <- c("Means", "SEs")

size <- length(which(!is.na(qtlfile$pheno[,1])))

if(phantom == 2){gv <- fit.trait.summary1[1,4]}else{gv <- fit.trait.summary2[1,4]}
if(phantom == 2){ev <- fit.trait.summary1[2,4]}else{ev <- fit.trait.summary2[2,4]}
if(phantom == 2){br <- round.length1}else{br <- round.length2}

##Power to detect effect of QTL in "present" population in the "phantom" population
trait.powercalc <- powercalc("ri", 
                             n = size, 
                             effect = effect.size,
                             gen.var = gv, 
                             env.var = ev, 
                             thresh = summary(modelperms)[1,1], 
                             bio.reps = br
                               )
trait.powercalc

##Ok, but what about looking at the effect size in the "phantom population," by which I mean,
##look at the "phantom" population's marker effect for the marker nearest to the peak 
##within the QTL interval of the "present" population.

##Now find the peak within that interval in the "phantom" population

if(phantom == 2){phantommax <- which(s1[,2+2] == max(s1[which(s1[,"chr"] == stats[row,"chr"] 
                                     & s1[,"pos"] >= stats[row,"lowposition"] 
                                     & s1[,"pos"] <= stats[row,"highposition"]),2+2]))}else{phantommax <- which(s1[,2+1] == max(s1[which(s1[,"chr"] == stats[row,"chr"] & s1[,"pos"] >= stats[row,"lowposition"] & s1[,"pos"] <= stats[row,"highposition"]),2+1]))}  

##Pick out the chromosome and position of the closest marker to that locus
qc <- s1[phantommax,"chr"]
qp <- s1[phantommax,"pos"]
mname.phantom <- find.marker(qtlfile, qc, qp)
mname.phantom

##Note mname.phantom. Is it the same marker as the peak from the "present" population (mname)?
comparison <- c(mname, mname.phantom)
names(comparison) <- c("mname", "mname.phantom")
#comparison

##Use n from "phantom" population
##Use effect from "phantom" population. Find effect of QTL in "present" population that is missing in "phantom" population
##Use gen.var from "phantom" population
##Use env.var from "phantom" population
##Use thresh from "phantom" population
##Use bio.reps from "phantom" population

output2 <- effectplot(qtlfile, pheno.col = 2, mname1=mname.phantom)
effect.size2 <- abs((output2$Means[1] - output2$Means[2])/2)
output.matrix2 <- rbind(output.matrix,t(rbind(output2$Means, output2$SEs)))
write.csv(output.matrix2, paste0("marker.effects.", stats[row,"terms"], ".csv")); size <- length(which(!is.na(qtlfile$pheno[,2]))); if(phantom == 2){gv <- fit.trait.summary2[1,4]}else{gv <- fit.trait.summary1[1,4]}; if(phantom == 2){ev <- fit.trait.summary2[2,4]}else{ev <- fit.trait.summary1[2,4]}; if(phantom == 2){br <- round.length2}else{br <- round.length1}

##Power to detect effect of QTL in "present" population in the "phantom" population
trait.powercalc2 <- powercalc("ri", 
                             n = size, 
                             effect = effect.size2,
                             gen.var = gv, 
                             env.var = ev, 
                             thresh = summary(modelperms)[1,2], 
                             bio.reps = br
)
trait.powercalc2

marker.compare <- cbind(
  
  rbind(mname, mname.phantom),
  rbind(trait.powercalc, trait.powercalc2),
  rbind(effect.size, effect.size2),
  rbind(length(which(!is.na(qtlfile$pheno[,present]))), length(which(!is.na(qtlfile$pheno[,2])))),
  rbind(if(phantom == 2){heritability1}else{heritability2}, if(phantom == 1){heritability1}else{heritability2}),
  rbind(summary(modelperms)[1,if(phantom == 2){1}else{2}], summary(modelperms)[1,if(phantom == 1){1}else{2}]),
  rbind(if(phantom == 2){round.length1}else{round.length2}, if(phantom == 1){round.length1}else{round.length2}),
  rbind(s1[which(rownames(s1) == mname), if(phantom == 2){present+2}else{2+2}], s1[which(rownames(s1) == mname.phantom), if(phantom == 1){present+2}else{2+2}]),
  rbind(s1[which(rownames(s1) == mname), "chr"], s1[which(rownames(s1) == mname.phantom), "chr"]),
  rbind(s1[which(rownames(s1) == mname), "pos"], s1[which(rownames(s1) == mname.phantom), "pos"])
  
)


colnames(marker.compare)[c(1,4,5,6,7,8,9,10,11)] <- c(
  
  "closest.marker",
  "effect.size",
  "n",
  "heritability",
  "threshhold",
  "bio.reps",
  "lod",
  "chr",
  "pos"
  
)

rownames(marker.compare) <- c(
  
  colnames(qtlfile$pheno)[present],
  colnames(qtlfile$pheno)[2]
  
)

marker.compare <- data.frame(marker.compare[,c(
  
      "closest.marker",
      "chr",
      "pos",
      "n",
      "bio.reps",
      "heritability",
      "effect.size",
      "percent.var.explained",
      "power",
      "threshhold",
      "lod"
  
    )

  ]

); marker.compare[,"heritability"] <- 1-(10^(-2*(as.numeric(marker.compare[,"lod"])/as.numeric(marker.compare[,"n"]))))

##close the PDF file
dev.off()

##Write to file
write.csv(marker.compare, paste0("marker.compare.", stats[row,"terms"], ".csv"))

